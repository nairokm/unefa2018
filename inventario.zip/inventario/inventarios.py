
from odoo import models, fields

class alfa(models.Model):
	_name = 'proyec.inven'
	_description = 'Inventario'

	name = fields.Char('Estudiante responsable del registro del equipo:', required=True, readonly=False,)
	usuario = fields.Char('Usuario:', required=True)
	departamento = fields.Char('Departamento:', required=True)
	extencion = fields.Char('Extención:', required=True)
	correoInterno = fields.Char('Correo Interno:', required=True)
	tipo = fields.Selection([('beta1','cpu'),('beta2','monitor'), ('beta3','teclado'),('beta4','mouse'),('beta5','cornetas'),('beta6','regulador')],'Tipo:')
	marca = fields.Char('Marca:', required=True)
	modelo = fields.Char('modelo:', required=False)
	serial = fields.Char('Serial:', required=False)
	bienNacional = fields.Char('Bien Nacional:', required=True)
	estado = fields.Selection([('beta1','buen estado'),('beta2','mal estado')],'Estado del equipo:')
	observacion = fields.Text('Observacion:', required=False)
	