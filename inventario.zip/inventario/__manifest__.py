{
	
	'name':'Inventario',
	'version': '1.0',
	'category': 'estudio',
	'summary': 'Evalucación de Programacion II',
	'description':'Evalucación de segundo cohorte',
	'website': 'http://www.unefa.edu.ve/portal/',
	'author':'Mary Medina y Alfonso Monrroy',
	'depends':['base'], 
	'application':'true',
	'data':['views/vista.xml', 'views/operador_registro.xml']


}